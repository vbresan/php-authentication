<?php include_once(dirname(__FILE__) . "/_verify.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Refresh" content="8; url=http://localhost/">
<title>localhost</title>
</head>
<body>
<center>
<h3>localhost</h3>
<h4>-- registration verification --</h4>
<hr width="75%" size="1">
<b><?php echo $userMessage ?></b>
<br><br>
Click <a href="http://localhost/">here</a> or wait few seconds for redirection to main page.
</center>
</body>
</html>
